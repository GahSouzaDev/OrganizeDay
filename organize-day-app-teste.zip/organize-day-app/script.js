// OrganizeDay - Sistema de Produtividade Pessoal
// Versão melhorada com todas as funcionalidades solicitadas

class OrganizeDay {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('organizeDayTasks')) || [];
        this.dietItems = JSON.parse(localStorage.getItem('organizeDayDiet')) || [];
        this.financeItems = JSON.parse(localStorage.getItem('organizeDayFinance')) || [];
        this.settings = JSON.parse(localStorage.getItem('organizeDaySettings')) || {
            theme: 'light',
            primaryColor: '#4361ee',
            timerSound: 'beep'
        };
        
        this.timer = {
            minutes: 25,
            seconds: 0,
            isRunning: false,
            interval: null
        };
        
        this.currentEditingDietId = null;
        this.reportChart = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSettings();
        this.renderTasks();
        this.renderDiet();
        this.renderFinance();
        this.updateTimerDisplay();
        this.setCurrentDate();
        this.createAudioContext();
    }

    // Configuração de eventos
    setupEventListeners() {
        // Navegação entre abas
        document.querySelectorAll('.tab').forEach(tab => {
            tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.section));
        });

        // Formulários
        document.getElementById('taskForm').addEventListener('submit', (e) => this.addTask(e));
        document.getElementById('dietForm').addEventListener('submit', (e) => this.addDietItem(e));
        document.getElementById('financeForm').addEventListener('submit', (e) => this.addFinanceItem(e));
        document.getElementById('editDietForm').addEventListener('submit', (e) => this.updateDietItem(e));

        // Timer
        document.getElementById('startTimer').addEventListener('click', () => this.startTimer());
        document.getElementById('pauseTimer').addEventListener('click', () => this.pauseTimer());
        document.getElementById('resetTimer').addEventListener('click', () => this.resetTimer());
        
        // Presets do timer
        document.querySelectorAll('.preset-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.setTimerPreset(parseInt(e.target.dataset.minutes)));
        });

        // Timer personalizado
        document.getElementById('customMinutes').addEventListener('change', (e) => {
            if (e.target.value) {
                this.setTimerPreset(parseInt(e.target.value));
            }
        });

        // Configurações
        document.getElementById('settingsBtn').addEventListener('click', () => this.openSettings());
        document.getElementById('closeSettings').addEventListener('click', () => this.closeSettings());
        document.getElementById('saveSettings').addEventListener('click', () => this.saveSettings());
        
        // Tema
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        // Cores
        document.querySelectorAll('.color-option').forEach(option => {
            option.addEventListener('click', (e) => this.selectColor(e.target.dataset.color));
        });

        // Relatórios
        document.getElementById('generateReport').addEventListener('click', () => this.generateReport());

        // Modal de edição de dieta
        document.getElementById('closeEditDiet').addEventListener('click', () => this.closeEditDietModal());

        // Fechar modais clicando fora
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });
    }

    // Definir data atual nos campos de data
    setCurrentDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('taskDate').value = today;
        document.getElementById('transactionDate').value = today;
    }

    // Navegação entre abas
    switchTab(section) {
        // Remover classe active de todas as abas e seções
        document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
        
        // Adicionar classe active na aba e seção selecionada
        document.querySelector(`[data-section="${section}"]`).classList.add('active');
        document.getElementById(section).classList.add('active');
    }

    // === GESTÃO DE TAREFAS ===
    addTask(e) {
        e.preventDefault();
        
        const title = document.getElementById('taskTitle').value.trim();
        const description = document.getElementById('taskDescription').value.trim();
        let date = document.getElementById('taskDate').value;
        const priority = document.getElementById('taskPriority').value;
        
        // Se não foi selecionada uma data, usar a data atual
        if (!date) {
            date = new Date().toISOString().split('T')[0];
        }
        
        if (!title) return;
        
        const task = {
            id: Date.now(),
            title,
            description,
            date,
            priority,
            completed: false,
            createdAt: new Date().toISOString()
        };
        
        this.tasks.push(task);
        this.saveTasks();
        this.renderTasks();
        
        // Limpar formulário
        document.getElementById('taskForm').reset();
        this.setCurrentDate(); // Redefinir data atual
    }

    toggleTask(id) {
        const task = this.tasks.find(t => t.id === id);
        if (task) {
            task.completed = !task.completed;
            this.saveTasks();
            this.renderTasks();
        }
    }

    deleteTask(id) {
        if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
            this.tasks = this.tasks.filter(t => t.id !== id);
            this.saveTasks();
            this.renderTasks();
        }
    }

    renderTasks() {
        const container = document.getElementById('tasksList');
        
        if (this.tasks.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 2rem;">Nenhuma tarefa adicionada ainda.</p>';
            return;
        }
        
        // Ordenar tarefas por data e prioridade
        const sortedTasks = this.tasks.sort((a, b) => {
            if (a.completed !== b.completed) return a.completed - b.completed;
            if (a.date !== b.date) return new Date(a.date) - new Date(b.date);
            
            const priorityOrder = { high: 3, medium: 2, low: 1 };
            return priorityOrder[b.priority] - priorityOrder[a.priority];
        });
        
        container.innerHTML = sortedTasks.map(task => `
            <div class="task-item priority-${task.priority} ${task.completed ? 'completed' : ''}">
                <div class="task-check">
                    <input type="checkbox" ${task.completed ? 'checked' : ''} 
                           onchange="app.toggleTask(${task.id})">
                </div>
                <div class="task-content">
                    <div class="task-title">${task.title}</div>
                    ${task.description ? `<div style="font-size: 0.85rem; color: var(--gray); margin-bottom: 4px;">${task.description}</div>` : ''}
                    <div class="task-time">
                        ${this.formatDate(task.date)} • 
                        <span class="priority-badge">${this.getPriorityLabel(task.priority)}</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="small danger" onclick="app.deleteTask(${task.id})" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    getPriorityLabel(priority) {
        const labels = {
            low: 'Baixa',
            medium: 'Média',
            high: 'Alta'
        };
        return labels[priority] || priority;
    }

    saveTasks() {
        localStorage.setItem('organizeDayTasks', JSON.stringify(this.tasks));
    }

    // === CRONÓMETRO ===
    setTimerPreset(minutes) {
        if (!this.timer.isRunning) {
            this.timer.minutes = minutes;
            this.timer.seconds = 0;
            this.updateTimerDisplay();
            document.getElementById('customMinutes').value = minutes;
        }
    }

    startTimer() {
        if (!this.timer.isRunning) {
            this.timer.isRunning = true;
            this.timer.interval = setInterval(() => {
                if (this.timer.seconds > 0) {
                    this.timer.seconds--;
                } else if (this.timer.minutes > 0) {
                    this.timer.minutes--;
                    this.timer.seconds = 59;
                } else {
                    this.timerFinished();
                    return;
                }
                this.updateTimerDisplay();
            }, 1000);
            
            document.getElementById('startTimer').style.display = 'none';
            document.getElementById('pauseTimer').style.display = 'inline-flex';
        }
    }

    pauseTimer() {
        this.timer.isRunning = false;
        clearInterval(this.timer.interval);
        
        document.getElementById('startTimer').style.display = 'inline-flex';
        document.getElementById('pauseTimer').style.display = 'none';
    }

    resetTimer() {
        this.pauseTimer();
        this.timer.minutes = 25;
        this.timer.seconds = 0;
        this.updateTimerDisplay();
        document.getElementById('customMinutes').value = '';
    }

    timerFinished() {
        this.pauseTimer();
        this.playTimerSound();
        
        // Mostrar notificação
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('OrganizeDay', {
                body: 'Tempo esgotado! Hora de fazer uma pausa.',
                icon: 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⏰</text></svg>'
            });
        }
        
        alert('Tempo esgotado! Hora de fazer uma pausa. 🎉');
    }

    updateTimerDisplay() {
        const display = document.getElementById('timerDisplay');
        const minutes = String(this.timer.minutes).padStart(2, '0');
        const seconds = String(this.timer.seconds).padStart(2, '0');
        display.textContent = `${minutes}:${seconds}`;
    }

    // === CONTROLE DE DIETA ===
    addDietItem(e) {
        e.preventDefault();
        
        const name = document.getElementById('foodName').value.trim();
        const calories = parseInt(document.getElementById('foodCalories').value) || 0;
        const quantity = document.getElementById('foodQuantity').value.trim();
        const mealType = document.getElementById('mealType').value;
        
        if (!name) return;
        
        const dietItem = {
            id: Date.now(),
            name,
            calories,
            quantity,
            mealType,
            date: new Date().toISOString().split('T')[0],
            createdAt: new Date().toISOString()
        };
        
        this.dietItems.push(dietItem);
        this.saveDiet();
        this.renderDiet();
        
        // Limpar formulário
        document.getElementById('dietForm').reset();
    }

    editDietItem(id) {
        const item = this.dietItems.find(d => d.id === id);
        if (!item) return;
        
        this.currentEditingDietId = id;
        
        // Preencher formulário de edição
        document.getElementById('editFoodName').value = item.name;
        document.getElementById('editFoodCalories').value = item.calories;
        document.getElementById('editFoodQuantity').value = item.quantity;
        document.getElementById('editMealType').value = item.mealType;
        
        // Abrir modal
        document.getElementById('editDietModal').classList.add('active');
    }

    updateDietItem(e) {
        e.preventDefault();
        
        if (!this.currentEditingDietId) return;
        
        const item = this.dietItems.find(d => d.id === this.currentEditingDietId);
        if (!item) return;
        
        item.name = document.getElementById('editFoodName').value.trim();
        item.calories = parseInt(document.getElementById('editFoodCalories').value) || 0;
        item.quantity = document.getElementById('editFoodQuantity').value.trim();
        item.mealType = document.getElementById('editMealType').value;
        
        this.saveDiet();
        this.renderDiet();
        this.closeEditDietModal();
    }

    deleteDietItem(id) {
        if (confirm('Tem certeza que deseja excluir este item da dieta?')) {
            this.dietItems = this.dietItems.filter(d => d.id !== id);
            this.saveDiet();
            this.renderDiet();
        }
    }

    closeEditDietModal() {
        document.getElementById('editDietModal').classList.remove('active');
        this.currentEditingDietId = null;
    }

    renderDiet() {
        const container = document.getElementById('dietList');
        const today = new Date().toISOString().split('T')[0];
        const todayItems = this.dietItems.filter(item => item.date === today);
        
        if (todayItems.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: var(--gray); padding: 2rem;">Nenhum alimento registrado hoje.</p>';
        } else {
            // Agrupar por tipo de refeição
            const groupedItems = todayItems.reduce((groups, item) => {
                if (!groups[item.mealType]) groups[item.mealType] = [];
                groups[item.mealType].push(item);
                return groups;
            }, {});
            
            const mealLabels = {
                breakfast: 'Café da manhã',
                lunch: 'Almoço',
                dinner: 'Jantar',
                snack: 'Lanche'
            };
            
            container.innerHTML = Object.entries(groupedItems).map(([mealType, items]) => `
                <div style="margin-bottom: 1.5rem;">
                    <h4 style="color: var(--primary); margin-bottom: 0.5rem; font-size: 1rem;">
                        ${mealLabels[mealType]}
                    </h4>
                    ${items.map(item => `
                        <div class="diet-item">
                            <div class="diet-content">
                                <div class="diet-name">${item.name}</div>
                                <div class="diet-details">
                                    ${item.quantity} • ${item.calories} kcal
                                </div>
                            </div>
                            <div class="diet-actions">
                                <button class="small secondary" onclick="app.editDietItem(${item.id})" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="small danger" onclick="app.deleteDietItem(${item.id})" title="Excluir">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `).join('');
        }
        
        // Atualizar total de calorias
        const totalCalories = todayItems.reduce((sum, item) => sum + item.calories, 0);
        document.getElementById('totalCalories').textContent = `${totalCalories} kcal`;
    }

    getMealTypeLabel(mealType) {
        const labels = {
            breakfast: 'Café da manhã',
            lunch: 'Almoço',
            dinner: 'Jantar',
            snack: 'Lanche'
        };
        return labels[mealType] || mealType;
    }

    saveDiet() {
        localStorage.setItem('organizeDayDiet', JSON.stringify(this.dietItems));
    }

    // === CONTROLE FINANCEIRO ===
    addFinanceItem(e) {
        e.preventDefault();
        
        const description = document.getElementById('transactionDescription').value.trim();
        const amount = parseFloat(document.getElementById('transactionAmount').value);
        const type = document.getElementById('transactionType').value;
        let date = document.getElementById('transactionDate').value;
        
        if (!description || !amount) return;
        
        // Se não foi selecionada uma data, usar a data atual
        if (!date) {
            date = new Date().toISOString().split('T')[0];
        }
        
        const financeItem = {
            id: Date.now(),
            description,
            amount,
            type,
            date,
            createdAt: new Date().toISOString()
        };
        
        this.financeItems.push(financeItem);
        this.saveFinance();
        this.renderFinance();
        
        // Limpar formulário
        document.getElementById('financeForm').reset();
        this.setCurrentDate(); // Redefinir data atual
    }

    deleteFinanceItem(id) {
        if (confirm('Tem certeza que deseja excluir esta transação?')) {
            this.financeItems = this.financeItems.filter(f => f.id !== id);
            this.saveFinance();
            this.renderFinance();
        }
    }

    renderFinance() {
        const container = document.getElementById('financeList');
        
        if (this.financeItems.length === 0) {
            container.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--gray); padding: 2rem;">Nenhuma transação registrada.</td></tr>';
        } else {
            // Ordenar por data (mais recente primeiro)
            const sortedItems = this.financeItems.sort((a, b) => new Date(b.date) - new Date(a.date));
            
            container.innerHTML = sortedItems.map(item => `
                <tr>
                    <td>${this.formatDate(item.date)}</td>
                    <td>${item.description}</td>
                    <td>
                        <span class="${item.type === 'income' ? 'positive' : 'negative'}">
                            ${item.type === 'income' ? 'Receita' : 'Despesa'}
                        </span>
                    </td>
                    <td class="${item.type === 'income' ? 'positive' : 'negative'}">
                        ${item.type === 'income' ? '+' : '-'}€${item.amount.toFixed(2)}
                    </td>
                    <td>
                        <button class="small danger" onclick="app.deleteFinanceItem(${item.id})" title="Excluir">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
        
        this.updateFinanceSummary();
    }

    updateFinanceSummary() {
        const income = this.financeItems
            .filter(item => item.type === 'income')
            .reduce((sum, item) => sum + item.amount, 0);
        
        const expenses = this.financeItems
            .filter(item => item.type === 'expense')
            .reduce((sum, item) => sum + item.amount, 0);
        
        const balance = income - expenses;
        
        document.getElementById('totalIncome').textContent = `€${income.toFixed(2)}`;
        document.getElementById('totalExpenses').textContent = `€${expenses.toFixed(2)}`;
        
        const balanceElement = document.getElementById('totalBalance');
        balanceElement.textContent = `€${balance.toFixed(2)}`;
        balanceElement.className = `summary-value ${balance >= 0 ? 'positive' : 'negative'}`;
    }

    saveFinance() {
        localStorage.setItem('organizeDayFinance', JSON.stringify(this.financeItems));
    }

    // === RELATÓRIOS ===
    generateReport() {
        const reportType = document.getElementById('reportType').value;
        const reportPeriod = document.getElementById('reportPeriod').value;
        
        const reportContent = document.getElementById('reportContent');
        reportContent.style.display = 'block';
        
        if (reportType === 'tasks') {
            this.generateTasksReport(reportPeriod);
        } else {
            this.generateFinanceReport(reportPeriod);
        }
    }

    generateTasksReport(period) {
        const data = this.getFilteredData(this.tasks, period);
        
        // Estatísticas
        const totalTasks = data.length;
        const completedTasks = data.filter(t => t.completed).length;
        const pendingTasks = totalTasks - completedTasks;
        const completionRate = totalTasks > 0 ? (completedTasks / totalTasks * 100).toFixed(1) : 0;
        
        // Tarefas por prioridade
        const priorityStats = data.reduce((stats, task) => {
            stats[task.priority] = (stats[task.priority] || 0) + 1;
            return stats;
        }, {});
        
        // Atualizar estatísticas
        document.getElementById('statsGrid').innerHTML = `
            <div class="stat-card">
                <div class="stat-value">${totalTasks}</div>
                <div class="stat-label">Total de Tarefas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${completedTasks}</div>
                <div class="stat-label">Concluídas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${pendingTasks}</div>
                <div class="stat-label">Pendentes</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${completionRate}%</div>
                <div class="stat-label">Taxa de Conclusão</div>
            </div>
        `;
        
        // Gráfico de tarefas por prioridade
        this.createChart('doughnut', {
            labels: ['Alta', 'Média', 'Baixa'],
            datasets: [{
                data: [
                    priorityStats.high || 0,
                    priorityStats.medium || 0,
                    priorityStats.low || 0
                ],
                backgroundColor: ['#f72585', '#f59e0b', '#4ade80']
            }]
        }, 'Tarefas por Prioridade');
    }

    generateFinanceReport(period) {
        const data = this.getFilteredData(this.financeItems, period);
        
        // Estatísticas
        const totalIncome = data.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
        const totalExpenses = data.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
        const balance = totalIncome - totalExpenses;
        const transactions = data.length;
        
        // Atualizar estatísticas
        document.getElementById('statsGrid').innerHTML = `
            <div class="stat-card">
                <div class="stat-value">€${totalIncome.toFixed(2)}</div>
                <div class="stat-label">Total de Receitas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">€${totalExpenses.toFixed(2)}</div>
                <div class="stat-label">Total de Despesas</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">€${balance.toFixed(2)}</div>
                <div class="stat-label">Saldo</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${transactions}</div>
                <div class="stat-label">Transações</div>
            </div>
        `;
        
        // Gráfico de receitas vs despesas por mês
        const monthlyData = this.getMonthlyFinanceData(data);
        
        this.createChart('bar', {
            labels: monthlyData.labels,
            datasets: [
                {
                    label: 'Receitas',
                    data: monthlyData.income,
                    backgroundColor: '#4ade80'
                },
                {
                    label: 'Despesas',
                    data: monthlyData.expenses,
                    backgroundColor: '#f72585'
                }
            ]
        }, 'Receitas vs Despesas');
    }

    getFilteredData(data, period) {
        const now = new Date();
        let startDate;
        
        switch (period) {
            case 'week':
                startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                break;
            case 'month':
                startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                break;
            case 'year':
                startDate = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
                break;
            default:
                return data;
        }
        
        return data.filter(item => {
            const itemDate = new Date(item.date || item.createdAt);
            return itemDate >= startDate;
        });
    }

    getMonthlyFinanceData(data) {
        const monthlyStats = {};
        
        data.forEach(item => {
            const date = new Date(item.date);
            const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            
            if (!monthlyStats[monthKey]) {
                monthlyStats[monthKey] = { income: 0, expenses: 0 };
            }
            
            if (item.type === 'income') {
                monthlyStats[monthKey].income += item.amount;
            } else {
                monthlyStats[monthKey].expenses += item.amount;
            }
        });
        
        const sortedMonths = Object.keys(monthlyStats).sort();
        
        return {
            labels: sortedMonths.map(month => {
                const [year, monthNum] = month.split('-');
                const date = new Date(year, monthNum - 1);
                return date.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
            }),
            income: sortedMonths.map(month => monthlyStats[month].income),
            expenses: sortedMonths.map(month => monthlyStats[month].expenses)
        };
    }

    createChart(type, data, title) {
        const ctx = document.getElementById('reportChart').getContext('2d');
        
        if (this.reportChart) {
            this.reportChart.destroy();
        }
        
        this.reportChart = new Chart(ctx, {
            type: type,
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    },
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: type === 'bar' ? {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '€' + value.toFixed(2);
                            }
                        }
                    }
                } : {}
            }
        });
    }

    // === CONFIGURAÇÕES ===
    openSettings() {
        document.getElementById('settingsModal').classList.add('active');
        
        // Solicitar permissão para notificações
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }

    closeSettings() {
        document.getElementById('settingsModal').classList.remove('active');
    }

    saveSettings() {
        this.settings.timerSound = document.getElementById('timerSound').value;
        this.saveSettingsToStorage();
        this.closeSettings();
    }

    selectColor(color) {
        // Remover classe active de todas as opções
        document.querySelectorAll('.color-option').forEach(option => {
            option.classList.remove('active');
        });
        
        // Adicionar classe active na opção selecionada
        document.querySelector(`[data-color="${color}"]`).classList.add('active');
        
        // Atualizar cor principal
        this.settings.primaryColor = color;
        this.applyPrimaryColor(color);
    }

    applyPrimaryColor(color) {
        document.documentElement.style.setProperty('--primary', color);
        
        // Calcular cor secundária (mais escura)
        const rgb = this.hexToRgb(color);
        const darkerColor = `rgb(${Math.max(0, rgb.r - 30)}, ${Math.max(0, rgb.g - 30)}, ${Math.max(0, rgb.b - 30)})`;
        document.documentElement.style.setProperty('--secondary', darkerColor);
    }

    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        this.settings.theme = newTheme;
        this.saveSettingsToStorage();
        
        // Atualizar ícone
        const icon = document.querySelector('#themeToggle i');
        icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }

    loadSettings() {
        // Aplicar tema
        document.documentElement.setAttribute('data-theme', this.settings.theme);
        const themeIcon = document.querySelector('#themeToggle i');
        themeIcon.className = this.settings.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        
        // Aplicar cor principal
        this.applyPrimaryColor(this.settings.primaryColor);
        document.querySelector(`[data-color="${this.settings.primaryColor}"]`)?.classList.add('active');
        
        // Aplicar configurações do timer
        document.getElementById('timerSound').value = this.settings.timerSound;
    }

    saveSettingsToStorage() {
        localStorage.setItem('organizeDaySettings', JSON.stringify(this.settings));
    }

    // === ÁUDIO ===
    createAudioContext() {
        this.audioContext = null;
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (e) {
            console.log('Web Audio API não suportada');
        }
    }

    playTimerSound() {
        if (this.settings.timerSound === 'none') return;
        
        if (this.audioContext) {
            this.playBeepSound();
        } else {
            // Fallback para navegadores sem Web Audio API
            this.playFallbackSound();
        }
    }

    playBeepSound() {
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        if (this.settings.timerSound === 'beep') {
            oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime);
            oscillator.frequency.setValueAtTime(600, this.audioContext.currentTime + 0.1);
        } else if (this.settings.timerSound === 'chime') {
            oscillator.frequency.setValueAtTime(523.25, this.audioContext.currentTime); // C5
            oscillator.frequency.setValueAtTime(659.25, this.audioContext.currentTime + 0.2); // E5
            oscillator.frequency.setValueAtTime(783.99, this.audioContext.currentTime + 0.4); // G5
        }
        
        gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.5);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.5);
    }

    playFallbackSound() {
        // Criar um beep simples usando data URL
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
        audio.play().catch(() => {
            // Se não conseguir reproduzir, usar vibração (se disponível)
            if ('vibrate' in navigator) {
                navigator.vibrate([200, 100, 200]);
            }
        });
    }

    // === UTILITÁRIOS ===
    formatDate(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (date.toDateString() === today.toDateString()) {
            return 'Hoje';
        } else if (date.toDateString() === yesterday.toDateString()) {
            return 'Ontem';
        } else {
            return date.toLocaleDateString('pt-BR');
        }
    }
}

// Inicializar aplicação
const app = new OrganizeDay();

// Service Worker para PWA (opcional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => console.log('SW registrado'))
            .catch(error => console.log('SW falhou'));
    });
}

