# OrganizeDay - Sistema de Produtividade Pessoal

Uma aplicação web completa para organização pessoal com gestão de tarefas, cronómetro Pomodoro, controle de dieta e finanças pessoais.

## 🚀 Funcionalidades

### ✅ Gestão de Tarefas
- Adicionar, editar e excluir tarefas
- Definir prioridades (Alta, Média, Baixa)
- Marcar tarefas como concluídas
- Organização automática por data e prioridade
- Data atual definida automaticamente quando não especificada

### ⏰ Cronómetro Pomodoro
- Presets de tempo (5, 10, 15, 25 minutos)
- Tempo personalizado
- Controles de iniciar, pausar e parar
- Som de notificação ao final (beep ou sino)
- Notificações do navegador

### 🍎 Controle de Dieta
- Registar alimentos por refeição
- **NOVO**: Editar itens da dieta existentes
- Controle de calorias
- Organização por tipo de refeição
- Cálculo automático do total de calorias diárias

### 💰 Controle Financeiro
- Registar receitas e despesas
- Histórico de transações
- Resumo financeiro automático
- Data atual definida automaticamente

### 📊 Relatórios com Gráficos
- **NOVO**: Relatórios de tarefas com estatísticas
- **NOVO**: Relatórios financeiros com gráficos
- Filtros por período (semana, mês, ano)
- Gráficos interativos com Chart.js
- Estatísticas detalhadas

### ⚙️ Configurações
- **NOVO**: Personalização da cor principal
- Tema claro/escuro
- Configuração de som do cronómetro
- Armazenamento local de preferências

## 🎨 Melhorias Implementadas

### ✨ Edição de Itens da Dieta
- Botão de editar em cada item da dieta
- Modal de edição com todos os campos
- Atualização em tempo real

### 📈 Relatórios Avançados
- Relatórios de tarefas com gráfico de prioridades
- Relatórios financeiros com gráfico de receitas vs despesas
- Estatísticas detalhadas por período

### 📅 Correção de Datas
- Data atual definida automaticamente em tarefas
- Data atual definida automaticamente em transações financeiras
- Não mais datas fixas do desenvolvimento

### 🔊 Som no Cronómetro
- Som de beep simples e limpo
- Opção de sino
- Possibilidade de desativar o som
- Fallback para vibração em dispositivos móveis

### 🎨 Personalização de Cores
- 6 opções de cores principais
- Aplicação automática em toda a interface
- Cores secundárias calculadas automaticamente

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Design responsivo e moderno
- **JavaScript ES6+**: Funcionalidades interativas
- **Chart.js**: Gráficos e visualizações
- **LocalStorage**: Armazenamento de dados
- **PWA**: Progressive Web App
- **Service Worker**: Funcionalidade offline

## 📱 Compatibilidade

- ✅ Desktop (Chrome, Firefox, Safari, Edge)
- ✅ Mobile (iOS Safari, Chrome Mobile)
- ✅ Tablet
- ✅ Funciona offline (PWA)

## 🚀 Como Usar

1. Abra o arquivo `index.html` no seu navegador
2. A aplicação carregará com todas as funcionalidades
3. Use as abas no topo para navegar entre seções
4. Todos os dados são salvos automaticamente no navegador

### Gestão de Tarefas
1. Clique na aba "Tarefas"
2. Preencha o formulário com título, descrição, data e prioridade
3. Clique em "Adicionar Tarefa"
4. Use os checkboxes para marcar como concluída
5. Use o botão de lixeira para excluir

### Cronómetro
1. Clique na aba "Timer"
2. Escolha um preset ou defina tempo personalizado
3. Clique em "Iniciar" para começar
4. Use "Pausar" para interromper temporariamente
5. Use "Parar" para resetar o cronómetro

### Controle de Dieta
1. Clique na aba "Dieta"
2. Adicione alimentos com nome, calorias, quantidade e refeição
3. **NOVO**: Use o botão de editar para modificar itens existentes
4. Veja o total de calorias do dia automaticamente

### Controle Financeiro
1. Clique na aba "Finanças"
2. Adicione transações como receita ou despesa
3. Veja o resumo financeiro atualizado automaticamente
4. Consulte o histórico na tabela

### Relatórios
1. Clique na aba "Relatórios"
2. Escolha o tipo de relatório (Tarefas ou Financeiro)
3. Selecione o período desejado
4. Clique em "Gerar Relatório"
5. Veja estatísticas e gráficos interativos

### Configurações
1. Clique no ícone de engrenagem no cabeçalho
2. Escolha sua cor principal preferida
3. Configure o som do cronómetro
4. Clique em "Salvar Configurações"

## 🔧 Funcionalidades Técnicas

### Armazenamento Local
- Todas as informações são salvas no localStorage do navegador
- Dados persistem entre sessões
- Não há necessidade de servidor

### PWA (Progressive Web App)
- Pode ser instalada como aplicativo
- Funciona offline
- Ícone personalizado
- Experiência nativa

### Responsividade
- Design adaptável para todos os tamanhos de tela
- Interface otimizada para mobile
- Navegação por abas em dispositivos pequenos

## 🎯 Próximas Funcionalidades

- Sincronização na nuvem
- Exportação de dados
- Mais tipos de gráficos
- Lembretes e notificações
- Integração com calendário
- Backup automático

## 📄 Licença

Este projeto é de código aberto e está disponível sob a licença MIT.

## 🤝 Contribuições

Contribuições são bem-vindas! Sinta-se à vontade para:
- Reportar bugs
- Sugerir novas funcionalidades
- Enviar pull requests
- Melhorar a documentação

---

**OrganizeDay** - Organize seu dia, organize sua vida! 🌟

